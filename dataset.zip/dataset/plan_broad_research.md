# PLAN: Geniş Kapsamlı Allplan Bilgi Araştırması ve Entegrasyonu

Bu plan, Allplan'ın tüm aktif kullanılan sürümleri (2021, 2022, 2023, 2024, 2025, 2026) ve genel BIM standartları üzerine bir araştırma yaparak veri setini "evrensel" bir Allplan destek zekasına dönüştürmeyi hedefler.

## Görev Dağılımı (Orchestration)

### 1. Planlama (Phase 1)
- `project-planner`: Araştırma dikeylerinin (Mühendislik, Mimari, Lisanslama, API) belirlenmesi. (Şu an aktif)

### 2. Uygulama (Phase 2 - Onay Sonrası)
- **`search-specialist`**: Allplan Forum (Global), Reddit (r/BIM), Technical FAQ arşivleri ve kullanıcı gruplarında sürüm bağımsız "gizli" teknik ipuçlarının (Secret Tips) aranması.
- **`debugger`**: 2021-2025 arası en çok raporlanan 10 kronik hatanın ve kalıcı çözümlerinin listelenmesi.
- **`data-scientist`**: Verilerin yeni bir "Global Allplan Intelligence" katmanına dönüştürülmesi.
- **`documentation-writer`**: Rehberlerin, QA setinin ve Intent listesinin bu geniş kapsama göre revize edilmesi.

## Araştırma Dikeyleri
- **Mimari:** Cephe modelleme, akıllı sembol (Smart Symbol) yönetimi.
- **Mühendislik:** Donatı şemaları (Reinforcement Schedules) ve metraj optimizasyonu.
- **Sistem:** SQL database hataları, ağ üzerinden çalışma (Workgroup) kilitlenmeleri.
- **Visual Scripting:** Hazır node kütüphaneleri ve topluluk tarafından üretilen otomasyon araçları.

## Entegrasyon Stratejisi
1. Sürüm spesifik bilgiler (Örn: 2023'teki bir bug) net bir şekilde etiketlenecek.
2. `allplan_qa_dataset.json` dosyasına "Version-Neutral" (Sürüm Bağımsız) kategorisi eklenecek.
3. README.md, veri setinin tüm Allplan ekosistemini kapsadığını belirtecek şekilde güncellenecek.

---
**Onay Bekleniyor:** Sınırlamaları kaldırıp geniş aramayı başlatmak için onayınızı rica ederim.
